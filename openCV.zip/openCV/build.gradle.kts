plugins {
	alias(libs.plugins.android.library)
}

android {
	namespace = "org.opencv"
	compileSdk = 36
	
	defaultConfig {
		minSdk = 24
		
		testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
		//consumerProguardFiles("consumer-rules.pro")
		
		externalNativeBuild {
			cmake {
				arguments += "-DANDROID_STL=c++_shared"
				targets += "opencv_jni_shared"
			}
		}
	}
	
	buildTypes {
		release {
			isMinifyEnabled = false
//			proguardFiles(
//				getDefaultProguardFile("proguard-android-optimize.txt"),
//				"proguard-rules.pro"
//			)
		}
		debug {
		
		}
	}
	
	packaging {
		jniLibs {
			keepDebugSymbols += "**/*.so"
		}
	}
	
	sourceSets["main"].apply {
//		jniLibs.srcDirs("native/libs")
//		java.srcDirs("java/src")
//		res.srcDirs("java/res")
//		manifest.srcFile("java/AndroidManifest.xml")
	}
	
	externalNativeBuild {
//		cmake {
//			path = file("libcxx_helper/CMakeLists.txt")
//		}
	}
	
	buildFeatures {
		buildConfig = true
		prefabPublishing = true
	}
	
	compileOptions {
		sourceCompatibility = JavaVersion.VERSION_17
		targetCompatibility = JavaVersion.VERSION_17
	}
	
	prefab {
		create("opencv_jni_shared") {
			headers = "native/jni/include"
		}
	}
	
}

dependencies {
	implementation(libs.androidx.appcompat)
	implementation(libs.material)
	testImplementation(libs.junit)
	androidTestImplementation(libs.androidx.junit)
	androidTestImplementation(libs.androidx.espresso.core)
}